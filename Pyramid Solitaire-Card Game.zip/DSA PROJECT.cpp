#include <iostream>
#include <algorithm>
#include <random>
#include <ctime>
#include <string>
#include<stdexcept>
#include <limits>

using namespace std;

int top = 0, top1 = 0, game_choice;
string* deck = new string[52];
string* waste = new string[52];
string* stock = new string[52];

struct Node {
    string card;
    struct Node* fwd_left;
    struct Node* fwd_right;
    struct Node* bwd_left;
    struct Node* bwd_right;
}*root, * ptr, * flag, * par;

Node* getnode(string data) {
    Node* n = new Node;
    n->card = data;
    n->fwd_left = nullptr;
    n->fwd_right = nullptr;
    n->bwd_left = nullptr;
    n->bwd_right = nullptr;
    return n;
}

void create_tree() {
    Node* nodes[28];
    for (int i = 0; i < 28; i++) {
        nodes[i] = getnode(deck[i]);
    }

    root = nodes[0];

    // Row 0
    nodes[0]->fwd_left = nodes[1];
    nodes[0]->fwd_right = nodes[2];

    // Row 1
    nodes[1]->bwd_right = nodes[0];
    nodes[1]->fwd_left = nodes[3];
    nodes[1]->fwd_right = nodes[4];
    nodes[2]->bwd_left = nodes[0];
    nodes[2]->fwd_left = nodes[4];
    nodes[2]->fwd_right = nodes[5];

    // Row 2
    nodes[3]->bwd_right = nodes[1];
    nodes[3]->fwd_left = nodes[6];
    nodes[3]->fwd_right = nodes[7];
    nodes[4]->bwd_left = nodes[1];
    nodes[4]->bwd_right = nodes[2];
    nodes[4]->fwd_left = nodes[7];
    nodes[4]->fwd_right = nodes[8];
    nodes[5]->bwd_left = nodes[2];
    nodes[5]->fwd_left = nodes[8];
    nodes[5]->fwd_right = nodes[9];

    // Row 3
    nodes[6]->bwd_right = nodes[3];
    nodes[6]->fwd_left = nodes[10];
    nodes[6]->fwd_right = nodes[11];
    nodes[7]->bwd_left = nodes[3];
    nodes[7]->bwd_right = nodes[4];
    nodes[7]->fwd_left = nodes[11];
    nodes[7]->fwd_right = nodes[12];
    nodes[8]->bwd_left = nodes[4];
    nodes[8]->bwd_right = nodes[5];
    nodes[8]->fwd_left = nodes[12];
    nodes[8]->fwd_right = nodes[13];
    nodes[9]->bwd_left = nodes[5];
    nodes[9]->fwd_left = nodes[13];
    nodes[9]->fwd_right = nodes[14];

    // Row 4
    nodes[10]->bwd_right = nodes[6];
    nodes[10]->fwd_left = nodes[15];
    nodes[10]->fwd_right = nodes[16];
    nodes[11]->bwd_left = nodes[6];
    nodes[11]->bwd_right = nodes[7];
    nodes[11]->fwd_left = nodes[16];
    nodes[11]->fwd_right = nodes[17];
    nodes[12]->bwd_left = nodes[7];
    nodes[12]->bwd_right = nodes[8];
    nodes[12]->fwd_left = nodes[17];
    nodes[12]->fwd_right = nodes[18];
    nodes[13]->bwd_left = nodes[8];
    nodes[13]->bwd_right = nodes[9];
    nodes[13]->fwd_left = nodes[18];
    nodes[13]->fwd_right = nodes[19];
    nodes[14]->bwd_left = nodes[9];
    nodes[14]->fwd_left = nodes[19];
    nodes[14]->fwd_right = nodes[20];

    // Row 5
    nodes[15]->bwd_right = nodes[10];
    nodes[15]->fwd_left = nodes[21];
    nodes[15]->fwd_right = nodes[22];
    nodes[16]->bwd_left = nodes[10];
    nodes[16]->bwd_right = nodes[11];
    nodes[16]->fwd_left = nodes[22];
    nodes[16]->fwd_right = nodes[23];
    nodes[17]->bwd_left = nodes[11];
    nodes[17]->bwd_right = nodes[12];
    nodes[17]->fwd_left = nodes[23];
    nodes[17]->fwd_right = nodes[24];
    nodes[18]->bwd_left = nodes[12];
    nodes[18]->bwd_right = nodes[13];
    nodes[18]->fwd_left = nodes[24];
    nodes[18]->fwd_right = nodes[25];
    nodes[19]->bwd_left = nodes[13];
    nodes[19]->bwd_right = nodes[14];
    nodes[19]->fwd_left = nodes[25];
    nodes[19]->fwd_right = nodes[26];
    nodes[20]->bwd_left = nodes[14];
    nodes[20]->fwd_left = nodes[26];
    nodes[20]->fwd_right = nodes[27];

    // Row 6
    nodes[21]->bwd_right = nodes[15];
    nodes[22]->bwd_left = nodes[15];
    nodes[22]->bwd_right = nodes[16];
    nodes[23]->bwd_left = nodes[16];
    nodes[23]->bwd_right = nodes[17];
    nodes[24]->bwd_left = nodes[17];
    nodes[24]->bwd_right = nodes[18];
    nodes[25]->bwd_left = nodes[18];
    nodes[25]->bwd_right = nodes[19];
    nodes[26]->bwd_left = nodes[19];
    nodes[26]->bwd_right = nodes[20];
    nodes[27]->bwd_left = nodes[20];
}

bool home_screen() {
    cout << "1. Play      2. Rules        3. Exit\n";
    cin >> game_choice;
    if (game_choice == 1)
        return true;
    else if (game_choice == 2) {
        cout << "Rules:\n";
        cout << "1. Your goal is to clear the pyramid by pairing cards that sum up to 13.\n";
        cout << "2. Kings (K) can be removed singly as they are worth 13 points.\n";
        cout << "3. Queens (Q), Jacks (J), and 10s can be paired with other cards.\n";
        cout << "4. Aces (A) can only be paired with 2s.\n";
        cout << "5. You can pair any two cards that sum up to 13 (e.g., 7 and 6).\n";
        cout << "6. The stock pile allows you to draw new cards when you're stuck.\n";
        cout << "7. You can rotate the stock pile if necessary.\n";
        cout << "8. You win the game if you clear the pyramid, otherwise, you lose if no more pairs can be made.\n";
        cout << "Press Enter to continue...";
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cin.get();
        return false;
    }
    else {
        exit(0);
    }
}

long int random() {
    srand((unsigned)time(0));
    int randomNumber = rand() % 100;
    return randomNumber;
}

int* num_arr() {
    int* arr = new int[52];
    for (int i = 0; i < 52; i++) {
        arr[i] = i + 1;
    }

    long int random_number = random();
    shuffle(arr, arr + 52, default_random_engine(random_number));
    return arr;
}

void number_to_card(int* arr) {
    string suit;
    int rem_cards;
    for (int i = 0; i < 52; i++) {
        if (arr[i] <= 52 && arr[i] > 39) {
            suit = "S";
            rem_cards = 39;
        }
        else if (arr[i] <= 39 && arr[i] > 26) {
            suit = "C";
            rem_cards = 26;
        }
        else if (arr[i] <= 26 && arr[i] > 13) {
            suit = "H";
            rem_cards = 13;
        }
        else {
            suit = "D";
            rem_cards = 0;
        }

        int card_value = arr[i] - rem_cards;
        switch (card_value) {
        case 1:
            deck[i] = "A" + suit;
            break;
        case 11:
            deck[i] = "J" + suit;
            break;
        case 12:
            deck[i] = "Q" + suit;
            break;
        case 13:
            deck[i] = "K" + suit;
            break;
        default:
            deck[i] = to_string(card_value) + suit;
        }
    }
}

void remaining_cards() {
    for (int i = 28; i <= 51; i++) {
        top++;
        stock[i - 27] = deck[i];
    }
}

void display() {
    for (int i = 0; i < 10; i++)
        cout << "\n";
    int indentation = 6;
    cout << "\n\n\nPYRAMID:-\n\n\n";
    ptr = root;
    flag = ptr;

    while (flag != nullptr) {
        if (flag == ptr) {
            for (int i = 0; i < indentation; i++)
                cout << "\t";
            indentation--;
        }
        cout << ptr->card << "\t\t";
        if (ptr->bwd_right != nullptr)
            ptr = ptr->bwd_right->fwd_right;
        else {
            ptr = flag->fwd_left;
            flag = ptr;
            cout << "\n\n";
        }
    }
    cout << "Stock : " << stock[top] << "\t" << "Waste : " << waste[top1];
}

string cardtoupper(string card1) {
    for (char& c : card1)
        c = toupper(c);
    return card1;
}

bool validity_check(string card1) {
    ptr = root;
    flag = ptr;

    while (flag != nullptr) {
        if (ptr->card == card1) {
            if ((ptr->fwd_left == nullptr && ptr->fwd_right == nullptr) || (ptr->fwd_left->card == "" && ptr->fwd_right->card == "")) {
                return true;
            }
        }
        if (ptr->bwd_right != nullptr)
            ptr = ptr->bwd_right->fwd_right;
        else {
            ptr = flag->fwd_left;
            flag = ptr;
        }
    }

    if (top >= 0 && (stock[top] == card1 || top1 >= 0 && waste[top1] == card1)) {
        return true;
    }
    return false;
}


int card_to_number(string card) {
    if (card[0] == 'K')
        return 13;
    if (card[0] == 'Q')
        return 12;
    if (card[0] == 'J')
        return 11;
    if (card[0] == 'A')
        return 1;
    if (card.length() > 1 && card[1] == '0')
        return 10;
    return card[0] - '0';
}

void removecard(string card1) {
    ptr = root;
    flag = ptr;
    while (flag != nullptr) {
        if (ptr->card == card1) {
            ptr->card = "";
        }
        if (ptr->bwd_right != nullptr)
            ptr = ptr->bwd_right->fwd_right;
        else {
            ptr = flag->fwd_left;
            flag = ptr;
        }
    }

    if (top >= 0 && stock[top] == card1) {
        stock[top] = "";
        top--;
    }

    if (top1 >= 0 && waste[top1] == card1) {
        waste[top1] = "";
        top1--;
    }
}

void stock_rotation() {
    if (stock[top] == "") {
        while (waste[top1] != "") {
            top++;
            stock[top] = waste[top1];
            top1--;
        }
    }
    else {
        top1++;
        waste[top1] = stock[top];
        top--;
    }
}

bool winconditions() {
    return (stock[top] == "" && waste[top1] == "" && root->card == "");
}

bool endconditions() {
    string end_arr[10] = { "" };
    string end_arr1[30] = { "" };

    ptr = root;
    flag = ptr;
    int ind = 0;

    while (flag != nullptr) {
        if ((ptr->fwd_left == nullptr && ptr->fwd_right == nullptr) || (ptr->fwd_left->card == "" && ptr->fwd_right->card == "")) {
            if (ptr->card != "") {
                end_arr[ind] = ptr->card;
                ind++;
            }
        }
        if (ptr->bwd_right != nullptr)
            ptr = ptr->bwd_right->fwd_right;
        else {
            ptr = flag->fwd_left;
            flag = ptr;
        }
    }

    int i1 = 0;
    for (int i = 0; i <= top; i++) {
        if (stock[i] != "") {
            end_arr1[i1] = stock[i];
            i1++;
        }
    }

    for (int i = top1; i > -1; i--) {
        if (waste[i] != "") {
            end_arr1[i1] = waste[i];
            i1++;
        }
    }

    for (int i = 0; !end_arr[i].empty(); i++) {
        if (card_to_number(end_arr[i]) == 13)
            return true;

        for (int j = i + 1; !end_arr[j].empty(); j++) {
            if ((card_to_number(end_arr[i]) + card_to_number(end_arr[j])) == 13)
                return true;
        }
    }

    for (int i = 0; !end_arr1[i].empty(); i++) {
        for (int j = 0; !end_arr[j].empty(); j++) {
            if ((card_to_number(end_arr[i]) + card_to_number(end_arr1[j])) == 13)
                return true;
        }
    }

    for (int i = 0; !end_arr1[i].empty(); i++) {
        if (card_to_number(end_arr1[i]) == 13)
            return true;
        if ((card_to_number(end_arr1[i]) + card_to_number(end_arr1[i + 1])) == 13)
            return true;
    }
    return false;
}
void display_opening() {
    cout << R"(
*****************
*                                                 *
*                   WELCOME TO                    *
*               THE PYRAMID GAME!                 *
*                                                 *
*****************
    )" << endl;

    cout << R"(
____                              ._    ._   ____      ._  ._  _         ._                
\__   \_._.____    __ |_| _| /  /   __/ __ |  | |_|/  |__  ||__   ___  
 |     _<   |  |\_  _ \_  \  /     \|  |/ _ |   \__  \ /  _ \|  | |  \   _\_  \ |  \_  _ \/ __ \ 
 |    |    \_  | |  | \// _ \|  Y Y  \  / // |   /        (  <> )  ||  ||  |  / _ \|  ||  | \/\  __/ 
 |_|    / __| ||  (_  /_||  /_\_ |  /___  /\_/|_/_||| (_  /_|||    \__  >
           \/                 \/      \/        \/          \/                          \/                \/ 
    )" << endl;

    cout << "Get ready to clear the pyramid by pairing cards that sum up to 13!" << endl;
    cout << "Press 1 to Play, 2 to see Rules, or 3 to Exit." << endl;
}
int main() {
    display_opening();
    while (true) {
        if (home_screen())
            break;
    }

    int* arr = num_arr();
    number_to_card(arr);
    create_tree();
    remaining_cards();

    while (true) {
        if (winconditions()) {
            cout << "\nWon the Game! :) \n";
            break;
        }
        if (!endconditions()) {
            cout << "\nGame over ! :( \n";
            cout << "No more pairing options, better luck next time \n";
            break;
        }

        display();
        cout << "\n\nEnter choice:\n1.Card Selection\t2.Stock Rotation\t3.End Game\n~>";
        int choice;
        cin >> choice;
        if (choice == 1) {
            string card1, card2;
            while (true) {
                cout << "\nEnter card 1 or B - back : ";
                cin >> card1;
                card1 = cardtoupper(card1);

                if (card1 == "B")
                    break;

                if (validity_check(card1) && card1[0] == 'K') {
                    removecard(card1);
                    break;
                }

                if (validity_check(card1)) {
                    cout << "\nEnter card 2 or B - back : ";
                    cin >> card2;
                    card2 = cardtoupper(card2);
                    if (card2 == "B")
                        break;
                    if (validity_check(card2)) {
                        if ((card_to_number(card1) + card_to_number(card2)) == 13) {
                            removecard(card1);
                            removecard(card2);
                            break;
                        }
                        else {
                            cout << "\nSum not equal to 13!\n";
                        }
                    }
                    else {
                        cout << "\nPlease enter a valid card!\n";
                    }
                }
                else {
                    cout << "\nPlease enter a valid card!\n";
                }
            }
        }
        else if (choice == 2) {
            stock_rotation();
        }
        else if (choice == 3) {
            break;
        }
    }
    return 0;
}